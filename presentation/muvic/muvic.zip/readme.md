# Slide using modern UVic template
## equations


$$ \Pi = \sum_{t=1}^T \left [   P_{A,t} D_t  - \sum_{i=1}^I (OM_i + b_i + \tau ϕ_i) Q_{i,t} + \sum_{k=1}^K  [  (P_{k,t} - \delta ) X_{k,t} - (P_{k,t} + \delta) M_{k,t}  ] \right ]  - \sum_{i = 1}^I (a_i - d_i) ∇ C_i, k \in \left \{ BC, MID, SK\right \}  $$
