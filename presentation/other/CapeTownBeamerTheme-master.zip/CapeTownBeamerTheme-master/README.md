# CapeTownBeamerTheme
This repository provides a `.sty` file, a `.tex` file, and a compiled PDF of slides from the "Cape Town" Beamer theme. The theme name is in honor of [Rob Garlick](http://www.robgarlick.com/), who hails from Cape Town, RSA, and who introduced me to this format.
